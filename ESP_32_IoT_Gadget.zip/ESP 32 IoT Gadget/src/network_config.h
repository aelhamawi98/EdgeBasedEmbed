# include<Arduino.h>

#define IO_USERNAME  "JJP24"
#define IO_KEY       "aio_wWIO72C2qdhQAjv0pJsqMgpBDy8t"

// home network credentials
#define WIFI_SSID  " "
#define WIFI_PASS  " "

#include "AdafruitIO_WiFi.h"



